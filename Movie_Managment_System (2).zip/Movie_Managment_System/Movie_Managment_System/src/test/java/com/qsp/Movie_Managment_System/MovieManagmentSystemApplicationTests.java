package com.qsp.Movie_Managment_System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MovieManagmentSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
