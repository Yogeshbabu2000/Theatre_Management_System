package com.qsp.Movie_Managment_System.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.qsp.Movie_Managment_System.dto.Owner;

public interface OwnerRepo extends JpaRepository<Owner, Integer>{

}
