package com.qsp.Movie_Managment_System;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MovieManagmentSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(MovieManagmentSystemApplication.class, args);
	}

}
